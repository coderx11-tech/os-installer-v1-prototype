#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include "img_builder.h"
#include <unistd.h>

void request_storage_permission() {
    char perm;
    printf("This program needs permission to access storage. Grant? [y/n]: ");
    scanf(" %c", &perm);
    if(perm != 'y' && perm != 'Y') {
        printf("Permission denied.\n");
        exit(1);
    }
}

int create_img_from_dir(const char* source_dir, const char* output_img) {
    struct stat st;
    if(stat(source_dir, &st) != 0 || !S_ISDIR(st.st_mode)) {
        printf("Invalid directory\n");
        return -1;
    }

    char cmd[1024];
    printf("Creating image file...\n");
    snprintf(cmd, sizeof(cmd), "dd if=/dev/zero of=%s bs=1M count=256", output_img);
    system(cmd);

    printf("Formatting image as ext4...\n");
    snprintf(cmd, sizeof(cmd), "mkfs.ext4 -F %s", output_img);
    system(cmd);

    printf("Mounting image...\n");
    system("mkdir -p /tmp/runner_mount");
    snprintf(cmd, sizeof(cmd), "sudo mount -o loop %s /tmp/runner_mount", output_img);
    system(cmd);

    printf("Copying files from source directory...\n");
    snprintf(cmd, sizeof(cmd), "cp -r %s/* /tmp/runner_mount/", source_dir);
    system(cmd);

    printf("Installing GRUB bootloader...\n");
    snprintf(cmd, sizeof(cmd), "sudo grub-install --target=i386-pc --boot-directory=/tmp/runner_mount/boot %s", output_img);
    system(cmd);

    printf("Unmounting image...\n");
    system("sudo umount /tmp/runner_mount");

    printf("Image created successfully: %s\n", output_img);
    return 0;
}
