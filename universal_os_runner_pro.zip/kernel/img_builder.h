#ifndef IMG_BUILDER_H
#define IMG_BUILDER_H
int create_img_from_dir(const char* source_dir, const char* output_img);
void request_storage_permission();
#endif
