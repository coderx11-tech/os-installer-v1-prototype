#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "installer.h"

void install_img(const char* img_path, const char* device) {
    char perm[4];
    printf("WARNING: Installing %s to %s will overwrite all data on the device!\n", img_path, device);
    printf("Type 'YES' to continue: ");
    scanf("%s", perm);
    if(strcmp(perm, "YES") != 0) {
        printf("Installation cancelled.\n");
        return;
    }
    char cmd[1024];
    printf("Writing image to device...\n");
    snprintf(cmd, sizeof(cmd), "sudo dd if=%s of=%s bs=4M status=progress conv=fsync", img_path, device);
    system(cmd);
    printf("Installation complete.\n");
}
