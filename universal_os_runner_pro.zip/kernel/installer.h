#ifndef INSTALLER_H
#define INSTALLER_H
void install_img(const char* img_path, const char* device);
#endif
