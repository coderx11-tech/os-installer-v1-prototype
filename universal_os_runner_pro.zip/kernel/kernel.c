#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "img_builder.h"
#include "runner.h"
#include "installer.h"

int main() {
    int choice;
    char path[512];
    char device[128];
    while(1) {
        printf("=== Universal OS Runner ===\n1. Generate OS Image\n2. Run OS Image\n3. Install OS to Device\n4. Manage Templates\n5. System Info\nChoice: ");
        scanf("%d", &choice);
        switch(choice) {
            case 1:
                printf("Enter directory path to build .img: ");
                scanf("%s", path);
                request_storage_permission();
                create_img_from_dir(path, "output/user_image.img");
                break;
            case 2:
                printf("Enter path of .img to run: ");
                scanf("%s", path);
                run_img(path);
                break;
            case 3:
                printf("Enter path of .img to install: ");
                scanf("%s", path);
                printf("Enter target device (e.g., /dev/sdb): ");
                scanf("%s", device);
                install_img(path, device);
                break;
            default:
                printf("Option not implemented yet.\n");
        }
    }
    return 0;
}
