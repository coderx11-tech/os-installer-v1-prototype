#include <stdio.h>
#include <stdlib.h>
void run_img(const char* path) {
    char cmd[1024];
    printf("Launching %s in QEMU...\n", path);
    snprintf(cmd, sizeof(cmd), "qemu-system-x86_64 -hda %s -m 512", path);
    system(cmd);
}
