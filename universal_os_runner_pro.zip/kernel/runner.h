#ifndef RUNNER_H
#define RUNNER_H
void run_img(const char* path);
#endif
